Faciliator port: 50005
Masterserver port: 23466

Put this in your code:

MasterServer.ipAddress = "127.0.0.1";
MasterServer.port = 23466;
Network.natFacilitatorIP = "127.0.0.1";
Network.natFacilitatorPort = 50005;


Run Start Masterserver.bat to start the masterserver!
Then run start facilitator.bat to start the facilitator! Enjoy!